package com.submarine.submarine;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
