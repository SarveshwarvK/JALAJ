package com.example.submarine_rc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
